Assignment #6
Author: Mengwen Li (mli2)
Link to the website: http://mli-cs4241-hw6.herokuapp.com/
Explanation for technical achievements:
1. The color for the header is changed when mouse is moving in the header region. This is achieved by adding mousemove event on header.
2. The navigation bar can follow scrolling. This is achieved by adding scroll event to window and changing the offset navigation bar according to the scroll amount.
3. For the "Bubble and capturing Demo" section, there's a delay when the background color of another layer is changed. This is achieved by using the 'setTimeout' function to delay the execution of the event handler.
4. Implemented drag and drop of an image by setting dragstart, dragend, dragover and drop events.
