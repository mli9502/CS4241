Assignment #8
Author: Mengwen Li (mli2)
Link to the page: http://mli-cs4241-hw8.herokuapp.com/
The website is tested under incognito mode to make sure that initial cookie is clean.
Technical achievements:
1. The message user sent will be displayed immediately on the body.
2. local storage is implemented. When a user has loaded the posts from server,
   they will be stored in local storage. When ever this user publish a new post
   the local history will be updated. This provides a faster speed when a single
   user is using the website.
