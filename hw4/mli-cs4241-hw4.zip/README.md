# Assignment #2

All files in `public` folder will be available to the world!
